# Crash Analyzer Telegram Bot

Telegram bot بسيط لتسجيل وتحليل نتائج Crash السابقة.

## المميزات

- /start
- /add 3.59
- /history
- /stats
- أزرار Inline
- SQLite لتخزين النتائج
- مناسب للتشغيل محلياً أو على Railway

## 1. إنشاء Bot Token

في Telegram افتح BotFather وأنشئ Bot جديد، ثم خذ BOT TOKEN.

## 2. التشغيل محلياً

ثبت Python 3.12 ثم:

```bash
pip install -r requirements.txt
```

Linux/macOS:

```bash
export BOT_TOKEN="ضع_التوكن_هنا"
python main.py
```

Windows PowerShell:

```powershell
$env:BOT_TOKEN="ضع_التوكن_هنا"
python main.py
```

## 3. Railway

ارفع الملفات إلى GitHub ثم أنشئ Service جديد من GitHub.

في Railway أضف Variable:

```text
BOT_TOKEN=توكن_البوت_هنا
```

وسيستعمل Railway الـ Procfile:

```text
worker: python main.py
```

## ملاحظة

البوت لا يتنبأ بالـ Crash القادم ولا ينفذ رهانات. التحليل مبني فقط على النتائج التي يتم تسجيلها.
